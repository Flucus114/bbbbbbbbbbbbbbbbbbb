package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.logging.LogUtils;
import com.mojang.math.Axis;
import com.mojang.datafixers.util.Pair;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.WardenModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BannerRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BannerItem;
import net.minecraft.world.item.DyeableLeatherItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BannerBlockEntity;
import net.minecraft.world.level.block.entity.BannerPattern;
import org.slf4j.Logger;

import java.util.List;

/** Desenha o capacete na cabeça e o estandarte nas costas do Warden. */
public class WardenGearLayer extends RenderLayer<Warden, WardenModel<Warden>> {
    private static final Logger LOGGER = LogUtils.getLogger();

    private final HumanoidModel<LivingEntity> armorModel;
    private final ModelPart flag;
    private boolean broken = false;

    public WardenGearLayer(RenderLayerParent<Warden, WardenModel<Warden>> parent, EntityModelSet models) {
        super(parent);
        this.armorModel = new HumanoidModel<>(models.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR));
        this.flag = models.bakeLayer(ModelLayers.BANNER).getChild("flag");
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, Warden w, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (broken) return;
        ItemStack helm = w.getItemBySlot(EquipmentSlot.HEAD);
        ItemStack banner = w.getItemBySlot(EquipmentSlot.CHEST);
        boolean hasBanner = banner.getItem() instanceof BannerItem;
        if (helm.isEmpty() && !hasBanner) return;
        try {
            ModelPart bone = getParentModel().root().getChild("bone");
            ModelPart body = bone.getChild("body");
            if (!helm.isEmpty()) renderHelmet(ps, buf, light, w, helm, bone, body, body.getChild("head"));
            if (hasBanner) renderBanner(ps, buf, light, banner, bone, body);
        } catch (RuntimeException ex) {
            broken = true;
            LOGGER.error("Falha ao renderizar equipamento do Warden; camada desativada", ex);
        }
    }

    private void renderHelmet(PoseStack ps, MultiBufferSource buf, int light, Warden w, ItemStack helm,
                              ModelPart bone, ModelPart body, ModelPart head) {
        ps.pushPose();
        bone.translateAndRotate(ps);
        body.translateAndRotate(ps);
        head.translateAndRotate(ps);
        if (helm.getItem() instanceof ArmorItem ai && ai.getEquipmentSlot() == EquipmentSlot.HEAD) {
            ps.scale(1.7F, 1.7F, 1.1F);
            boolean dyed = helm.getItem() instanceof DyeableLeatherItem;
            float r = 1F, g = 1F, b = 1F;
            if (dyed) {
                int c = ((DyeableLeatherItem) helm.getItem()).getColor(helm);
                r = ((c >> 16) & 255) / 255F;
                g = ((c >> 8) & 255) / 255F;
                b = (c & 255) / 255F;
            }
            VertexConsumer vc = ItemRenderer.getArmorFoilBuffer(buf,
                    RenderType.armorCutoutNoCull(armorTexture(ai, false)), false, helm.hasFoil());
            armorModel.head.render(ps, vc, light, OverlayTexture.NO_OVERLAY, r, g, b, 1.0F);
            if (dyed) {
                VertexConsumer vo = ItemRenderer.getArmorFoilBuffer(buf,
                        RenderType.armorCutoutNoCull(armorTexture(ai, true)), false, helm.hasFoil());
                armorModel.head.render(ps, vo, light, OverlayTexture.NO_OVERLAY, 1F, 1F, 1F, 1.0F);
            }
        } else {
            ps.translate(0.0F, -0.5F, 0.0F);
            ps.mulPose(Axis.YP.rotationDegrees(180.0F));
            ps.scale(1.25F, -1.25F, -1.25F);
            Minecraft.getInstance().getItemRenderer().renderStatic(helm, ItemDisplayContext.HEAD, light,
                    OverlayTexture.NO_OVERLAY, ps, buf, w.level(), w.getId());
        }
        ps.popPose();
    }

    private static ResourceLocation armorTexture(ArmorItem ai, boolean overlay) {
        String name = ai.getMaterial().getName();
        String ns = "minecraft";
        int i = name.indexOf(':');
        if (i != -1) {
            ns = name.substring(0, i);
            name = name.substring(i + 1);
        }
        return new ResourceLocation(ns, "textures/models/armor/" + name + "_layer_1" + (overlay ? "_overlay" : "") + ".png");
    }

    private void renderBanner(PoseStack ps, MultiBufferSource buf, int light, ItemStack banner,
                              ModelPart bone, ModelPart body) {
        ps.pushPose();
        bone.translateAndRotate(ps);
        body.translateAndRotate(ps);
        // costas (+z do corpo), a partir da parte alta, pendurado para baixo
        ps.translate(0.0F, -0.75F, 0.46F);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F));
        ps.scale(0.5F, 0.5F, 0.5F);
        flag.xRot = 0.0F;
        flag.yRot = 0.0F;
        flag.zRot = 0.0F;
        DyeColor base = ((BannerItem) banner.getItem()).getColor();
        List<Pair<Holder<BannerPattern>, DyeColor>> patterns =
                BannerBlockEntity.createPatterns(base, BannerBlockEntity.getItemPatterns(banner));
        BannerRenderer.renderPatterns(ps, buf, light, OverlayTexture.NO_OVERLAY, flag, ModelBakery.BANNER_BASE,
                true, patterns, banner.hasFoil());
        ps.popPose();
    }
}
