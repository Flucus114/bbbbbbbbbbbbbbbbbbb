package com.classselector;

import com.mojang.logging.LogUtils;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import org.slf4j.Logger;

/**
 * Lado do cliente da Espada do Olho Sombrio: pose de "guarda baixa" com as duas mãos.
 * Mãos na altura do quadril, levemente para o lado do braço principal, lâmina apontando para baixo (~35-40°).
 *
 * ANTES: criava um valor novo no enum HumanoidModel.ArmPose (ArmPose.create), o que quebra/crasha
 * (switches de enum de outros mods, enum não extendido etc.) assim que a espada era segurada.
 * AGORA: não mexe em enum nenhum. Troca o modelo do PlayerRenderer por uma subclasse de PlayerModel
 * que, depois da animação normal, ajusta os braços quando o jogador segura a espada.
 *
 * A orientação da espada na mão (display "thirdperson_*" em models/item/dark_eye_sword.json) foi calculada
 * para ESTES ângulos. Se mudar qualquer valor abaixo, o ângulo da espada na mão muda junto.
 */
@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class DarkEyeClient {
    private static final Logger LOGGER = LogUtils.getLogger();

    /** Braço que segura a espada (radianos): xRot negativo = para frente; yRot negativo = fecha para o centro (destro). */
    private static final float MAIN_X = -0.40F, MAIN_Y = -0.30F;
    /** Braço de apoio: cruza na frente do corpo até o cabo (yRot é espelhado para canhotos). */
    private static final float OFF_X = -0.94F, OFF_Y = 1.09F;

    private DarkEyeClient() {}

    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers e) {
        // Epic Fight controla a animação/renderização do jogador por conta própria (poses e golpes da arma).
        // Para não haver conflito, não mexemos no modelo do jogador quando ele está instalado.
        if (ModList.get().isLoaded("epicfight")) {
            LOGGER.info("Epic Fight detectado: pose de duas maos da Espada do Olho Sombrio desativada (o Epic Fight cuida da animacao).");
            return;
        }
        swapModel(e, "default", false);
        swapModel(e, "slim", true);
    }

    private static void swapModel(EntityRenderersEvent.AddLayers e, String skin, boolean slim) {
        try {
            PlayerRenderer renderer = e.getSkin(skin);
            if (renderer == null) return;
            PlayerModel<AbstractClientPlayer> model = new GuardModel(
                    e.getEntityModels().bakeLayer(slim ? ModelLayers.PLAYER_SLIM : ModelLayers.PLAYER), slim);
            // campo protegido "model" (f_115290_) de LivingEntityRenderer
            ObfuscationReflectionHelper.setPrivateValue(LivingEntityRenderer.class, renderer, model, "f_115290_");
        } catch (Throwable t) {
            LOGGER.warn("Nao foi possivel instalar a pose de duas maos da Espada do Olho Sombrio (skin {}); usando a pose padrao.", skin, t);
        }
    }

    /** PlayerModel normal, mas com a guarda baixa quando a espada está na mão principal. */
    private static final class GuardModel extends PlayerModel<AbstractClientPlayer> {
        GuardModel(ModelPart root, boolean slim) {
            super(root, slim);
        }

        @Override
        public void setupAnim(AbstractClientPlayer p, float limbSwing, float limbSwingAmount, float ageInTicks,
                              float netHeadYaw, float headPitch) {
            super.setupAnim(p, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            try {
                if (!(p.getMainHandItem().getItem() instanceof DarkEyeSwordItem)) return;
                if (p.isUsingItem() || this.attackTime > 0.0F || p.isFallFlying() || p.isSwimming()) return;
                apply(this, p.getMainArm());
            } catch (Throwable t) {
                // nunca derrubar a renderização por causa da pose
            }
        }
    }

    private static void apply(PlayerModel<?> model, HumanoidArm arm) {
        boolean right = arm == HumanoidArm.RIGHT;
        ModelPart main = right ? model.rightArm : model.leftArm;
        ModelPart off = right ? model.leftArm : model.rightArm;
        float side = right ? 1.0F : -1.0F; // espelha tudo para jogadores canhotos

        main.xRot = MAIN_X;
        main.yRot = side * MAIN_Y;
        main.zRot = 0.0F;

        off.xRot = OFF_X;
        off.yRot = side * OFF_Y;
        off.zRot = 0.0F;

        // as mangas copiam a rotação dos braços no fim do setupAnim
        model.leftSleeve.copyFrom(model.leftArm);
        model.rightSleeve.copyFrom(model.rightArm);
    }
}
