package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Modelo do Soberano Cósmico. GERADO por gen_boss.py (geometria + UVs da textura).
 * As animações ficam em setupAnim.
 */
public class CosmicBossModel extends EntityModel<CosmicBoss> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ClassSelectorMod.MODID, "cosmic_sovereign"), "main");
    private static final float RAD = (float) Math.PI / 180F;
    private static final float TORSO_Y = -39.0F;
    private static final int SPIKES = 10, SPIKE_SEGS = 4, TAIL_SEGS = 8, FING_SEGS = 3;

    private final ModelPart root, torso, head, eye, orb;
    private final ModelPart[] arm = new ModelPart[2], fore = new ModelPart[2], hand = new ModelPart[2];
    private final ModelPart[][][] fing = new ModelPart[2][5][FING_SEGS];
    private final float[][][] fingBaseX = new float[2][5][FING_SEGS], fingBaseZ = new float[2][5][FING_SEGS];
    private final ModelPart[][] spike = new ModelPart[SPIKES][SPIKE_SEGS];
    private final float[][] spikeBaseX = new float[SPIKES][SPIKE_SEGS], spikeBaseZ = new float[SPIKES][SPIKE_SEGS];
    private final ModelPart[] engineOrb = new ModelPart[3], tail = new ModelPart[TAIL_SEGS];
    /** Animação de arremesso por braço (0 = P, 1 = N): preparação 0..1 e soltura 1..0. */
    private final float[] throwWind = new float[2], throwRel = new float[2];

    public CosmicBossModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.head = torso.getChild("head");
        this.eye = head.getChild("eye");
        ModelPart pelvis = torso.getChild("pelvis");
        this.orb = pelvis.getChild("orb");
        String[] sides = {"P", "N"};
        for (int s = 0; s < 2; s++) {
            ModelPart sh = torso.getChild("shoulder" + sides[s]);
            arm[s] = sh.getChild("arm" + sides[s]);
            fore[s] = arm[s].getChild("fore" + sides[s]);
            hand[s] = fore[s].getChild("hand" + sides[s]);
            for (int k = 0; k < 5; k++) {
                ModelPart prev = hand[s];
                for (int m = 0; m < FING_SEGS; m++) {
                    fing[s][k][m] = prev.getChild("f" + sides[s] + k + "_" + m);
                    fingBaseX[s][k][m] = fing[s][k][m].xRot;
                    fingBaseZ[s][k][m] = fing[s][k][m].zRot;
                    prev = fing[s][k][m];
                }
            }
        }
        for (int i = 0; i < SPIKES; i++) {
            ModelPart prev = torso;
            for (int k = 0; k < SPIKE_SEGS; k++) {
                spike[i][k] = prev.getChild("sp" + i + "_" + k);
                spikeBaseX[i][k] = spike[i][k].xRot;
                spikeBaseZ[i][k] = spike[i][k].zRot;
                prev = spike[i][k];
            }
        }
        ModelPart pack = torso.getChild("pack");
        for (int i = 0; i < 3; i++) engineOrb[i] = pack.getChild("engine" + i).getChild("eorb" + i);
        ModelPart prev = pelvis;
        for (int i = 0; i < TAIL_SEGS; i++) { tail[i] = prev.getChild("tail" + i); prev = tail[i]; }
    }

    /** Tamanho (0..1) do orbe de energia que cresce na mão {@code s} durante a preparação do arremesso. */
    public float getChargeSize(int s) {
        return throwRel[s] > 0.0F ? 0.0F : throwWind[s];
    }

    /** Aplica ao PoseStack a transformação até a mão {@code s} (usado para desenhar o orbe de carga). */
    public void translateToHand(int s, PoseStack ps) {
        String side = s == 0 ? "P" : "N";
        torso.translateAndRotate(ps);
        torso.getChild("shoulder" + side).translateAndRotate(ps);
        arm[s].translateAndRotate(ps);
        fore[s].translateAndRotate(ps);
        hand[s].translateAndRotate(ps);
    }

    /** Calcula a fase do arremesso de cada braço a partir do tempo do ataque (ticks, com parcial). */
    private void computeThrow(CosmicBoss e, float at) {
        throwWind[0] = throwWind[1] = 0.0F;
        throwRel[0] = throwRel[1] = 0.0F;
        if (e.getAttack() != CosmicBoss.ATK_ORBS || at <= 0.0F) return;
        int[] shots = e.isPhase2() ? CosmicBoss.ORB_SHOTS_2 : CosmicBoss.ORB_SHOTS_1;
        for (int i = 0; i < shots.length; i++) {
            int arm = i & 1;
            float d = at - shots[i];
            if (d > -CosmicBoss.THROW_WINDUP && d <= 0.0F) {
                float x = (d + CosmicBoss.THROW_WINDUP) / CosmicBoss.THROW_WINDUP;     // 0..1
                throwWind[arm] = Math.max(throwWind[arm], x * x * (3.0F - 2.0F * x));  // suaviza
            } else if (d > 0.0F && d < CosmicBoss.THROW_RELEASE) {
                throwRel[arm] = Math.max(throwRel[arm], 1.0F - d / CosmicBoss.THROW_RELEASE);
            }
        }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition torso = root.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 0).addBox(-12F, -9F, -6F, 24F, 18F, 12F), PartPose.offsetAndRotation(0F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition head = torso.addOrReplaceChild("head", CubeListBuilder.create().texOffs(72, 0).addBox(-7F, -7F, -7F, 14F, 14F, 14F), PartPose.offsetAndRotation(0F, -17F, 0F, 0F, 0F, 0F));
        PartDefinition eye = head.addOrReplaceChild("eye", CubeListBuilder.create().texOffs(0, 256).addBox(-5F, -5F, -7.5F, 10F, 9F, 1F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition collar = torso.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(200, 53).addBox(-8F, -2F, -6F, 16F, 3F, 12F), PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, 0F));
        PartDefinition trapP = torso.addOrReplaceChild("trapP", CubeListBuilder.create().texOffs(96, 71).addBox(-4F, -3F, -5F, 8F, 4F, 10F), PartPose.offsetAndRotation(8F, -9F, 0F, 0F, 0F, 0.32F));
        PartDefinition trapN = torso.addOrReplaceChild("trapN", CubeListBuilder.create().texOffs(132, 71).addBox(-4F, -3F, -5F, 8F, 4F, 10F), PartPose.offsetAndRotation(-8F, -9F, 0F, 0F, 0F, -0.32F));
        PartDefinition hornP_0 = head.addOrReplaceChild("hornP_0", CubeListBuilder.create().texOffs(36, 111).addBox(-3F, -3F, -3F, 6F, 3F, 6F), PartPose.offsetAndRotation(6F, -6F, 0F, 0F, 0F, 0.35F));
        PartDefinition hornP_1 = hornP_0.addOrReplaceChild("hornP_1", CubeListBuilder.create().texOffs(60, 111).addBox(-3F, -3F, -3F, 6F, 3F, 6F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition hornP_2 = hornP_1.addOrReplaceChild("hornP_2", CubeListBuilder.create().texOffs(84, 130).addBox(-2F, -3F, -2F, 4F, 3F, 4F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition hornP_3 = hornP_2.addOrReplaceChild("hornP_3", CubeListBuilder.create().texOffs(100, 130).addBox(-2F, -3F, -2F, 4F, 3F, 4F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.05F));
        PartDefinition hornP_4 = hornP_3.addOrReplaceChild("hornP_4", CubeListBuilder.create().texOffs(184, 138).addBox(-1F, -3F, -1F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition hornP_5 = hornP_4.addOrReplaceChild("hornP_5", CubeListBuilder.create().texOffs(192, 138).addBox(-1F, -3F, -1F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition hornN_0 = head.addOrReplaceChild("hornN_0", CubeListBuilder.create().texOffs(84, 111).addBox(-3F, -3F, -3F, 6F, 3F, 6F), PartPose.offsetAndRotation(-6F, -6F, 0F, 0F, 0F, -0.35F));
        PartDefinition hornN_1 = hornN_0.addOrReplaceChild("hornN_1", CubeListBuilder.create().texOffs(108, 111).addBox(-3F, -3F, -3F, 6F, 3F, 6F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition hornN_2 = hornN_1.addOrReplaceChild("hornN_2", CubeListBuilder.create().texOffs(116, 130).addBox(-2F, -3F, -2F, 4F, 3F, 4F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition hornN_3 = hornN_2.addOrReplaceChild("hornN_3", CubeListBuilder.create().texOffs(132, 130).addBox(-2F, -3F, -2F, 4F, 3F, 4F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.05F));
        PartDefinition hornN_4 = hornN_3.addOrReplaceChild("hornN_4", CubeListBuilder.create().texOffs(200, 138).addBox(-1F, -3F, -1F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition hornN_5 = hornN_4.addOrReplaceChild("hornN_5", CubeListBuilder.create().texOffs(208, 138).addBox(-1F, -3F, -1F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition crown = head.addOrReplaceChild("crown", CubeListBuilder.create().texOffs(132, 53).addBox(-2F, -12F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(0F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition pecP = torso.addOrReplaceChild("pecP", CubeListBuilder.create().texOffs(152, 100).addBox(-4F, -3F, -3F, 8F, 7F, 3F), PartPose.offsetAndRotation(7F, -4F, -6F, 0F, 0F, 0F));
        PartDefinition pecN = torso.addOrReplaceChild("pecN", CubeListBuilder.create().texOffs(174, 100).addBox(-4F, -3F, -3F, 8F, 7F, 3F), PartPose.offsetAndRotation(-7F, -4F, -6F, 0F, 0F, 0F));
        PartDefinition ab0_0 = torso.addOrReplaceChild("ab0_0", CubeListBuilder.create().texOffs(216, 138).addBox(-2F, -1.5F, -2F, 4F, 3F, 2F), PartPose.offsetAndRotation(-2.5F, 1F, -6F, 0F, 0F, 0F));
        PartDefinition ab0_1 = torso.addOrReplaceChild("ab0_1", CubeListBuilder.create().texOffs(228, 138).addBox(-2F, -1.5F, -2F, 4F, 3F, 2F), PartPose.offsetAndRotation(2.5F, 1F, -6F, 0F, 0F, 0F));
        PartDefinition ab1_0 = torso.addOrReplaceChild("ab1_0", CubeListBuilder.create().texOffs(240, 138).addBox(-2F, -1.5F, -2F, 4F, 3F, 2F), PartPose.offsetAndRotation(-2.5F, 4.4F, -6F, 0F, 0F, 0F));
        PartDefinition ab1_1 = torso.addOrReplaceChild("ab1_1", CubeListBuilder.create().texOffs(0, 144).addBox(-2F, -1.5F, -2F, 4F, 3F, 2F), PartPose.offsetAndRotation(2.5F, 4.4F, -6F, 0F, 0F, 0F));
        PartDefinition ab2_0 = torso.addOrReplaceChild("ab2_0", CubeListBuilder.create().texOffs(12, 144).addBox(-2F, -1.5F, -2F, 4F, 3F, 2F), PartPose.offsetAndRotation(-2.5F, 7.8F, -6F, 0F, 0F, 0F));
        PartDefinition ab2_1 = torso.addOrReplaceChild("ab2_1", CubeListBuilder.create().texOffs(24, 144).addBox(-2F, -1.5F, -2F, 4F, 3F, 2F), PartPose.offsetAndRotation(2.5F, 7.8F, -6F, 0F, 0F, 0F));
        PartDefinition shoulderP = torso.addOrReplaceChild("shoulderP", CubeListBuilder.create().texOffs(84, 30).addBox(-6F, -4F, -6F, 12F, 8F, 12F), PartPose.offsetAndRotation(19F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition capP = shoulderP.addOrReplaceChild("capP", CubeListBuilder.create().texOffs(20, 53).addBox(-7F, -3F, -7F, 14F, 3F, 14F), PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition spsP0 = capP.addOrReplaceChild("spsP0", CubeListBuilder.create().texOffs(196, 100).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F), PartPose.offsetAndRotation(3.5F, -3F, 0F, 0F, 0F, 0.5F));
        PartDefinition spsP1 = capP.addOrReplaceChild("spsP1", CubeListBuilder.create().texOffs(208, 100).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F), PartPose.offsetAndRotation(-3.5F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition armP = shoulderP.addOrReplaceChild("armP", CubeListBuilder.create().texOffs(128, 0).addBox(-5F, 0F, -5F, 10F, 14F, 10F), PartPose.offsetAndRotation(0F, 3F, 0F, 0F, 0F, 0F));
        PartDefinition bicP = armP.addOrReplaceChild("bicP", CubeListBuilder.create().texOffs(132, 111).addBox(-4F, -3F, -3F, 8F, 6F, 3F), PartPose.offsetAndRotation(0F, 5F, -5F, 0F, 0F, 0F));
        PartDefinition foreP = armP.addOrReplaceChild("foreP", CubeListBuilder.create().texOffs(208, 0).addBox(-5F, 0F, -5F, 10F, 13F, 10F), PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, 0F));
        PartDefinition ringAP = foreP.addOrReplaceChild("ringAP", CubeListBuilder.create().texOffs(168, 71).addBox(-6F, 0F, -6F, 12F, 2F, 12F), PartPose.offsetAndRotation(0F, 3F, 0F, 0F, 0F, 0F));
        PartDefinition ringBP = foreP.addOrReplaceChild("ringBP", CubeListBuilder.create().texOffs(0, 71).addBox(-6F, 0F, -6F, 12F, 3F, 12F), PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition handP = foreP.addOrReplaceChild("handP", CubeListBuilder.create().texOffs(0, 100).addBox(-4F, 0F, -3F, 8F, 5F, 6F), PartPose.offsetAndRotation(0F, 13F, 0F, 0F, 0F, 0F));
        PartDefinition fP0_0 = handP.addOrReplaceChild("fP0_0", CubeListBuilder.create().texOffs(148, 130).addBox(-1.5F, 0F, -1.5F, 3F, 4F, 3F), PartPose.offsetAndRotation(-3.4F, 5F, 0F, -0.2F, 0F, 0.6F));
        PartDefinition fP0_1 = fP0_0.addOrReplaceChild("fP0_1", CubeListBuilder.create().texOffs(244, 130).addBox(-1F, 0F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP0_2 = fP0_1.addOrReplaceChild("fP0_2", CubeListBuilder.create().texOffs(36, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP1_0 = handP.addOrReplaceChild("fP1_0", CubeListBuilder.create().texOffs(0, 130).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(-1.7F, 5F, 0F, -0.2F, 0F, 0.3F));
        PartDefinition fP1_1 = fP1_0.addOrReplaceChild("fP1_1", CubeListBuilder.create().texOffs(160, 130).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP1_2 = fP1_1.addOrReplaceChild("fP1_2", CubeListBuilder.create().texOffs(42, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP2_0 = handP.addOrReplaceChild("fP2_0", CubeListBuilder.create().texOffs(12, 130).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.2F, 0F, 0F));
        PartDefinition fP2_1 = fP2_0.addOrReplaceChild("fP2_1", CubeListBuilder.create().texOffs(168, 130).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP2_2 = fP2_1.addOrReplaceChild("fP2_2", CubeListBuilder.create().texOffs(48, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP3_0 = handP.addOrReplaceChild("fP3_0", CubeListBuilder.create().texOffs(24, 130).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(1.7F, 5F, 0F, -0.2F, 0F, -0.3F));
        PartDefinition fP3_1 = fP3_0.addOrReplaceChild("fP3_1", CubeListBuilder.create().texOffs(176, 130).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP3_2 = fP3_1.addOrReplaceChild("fP3_2", CubeListBuilder.create().texOffs(54, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP4_0 = handP.addOrReplaceChild("fP4_0", CubeListBuilder.create().texOffs(184, 130).addBox(-1.5F, 0F, -1.5F, 3F, 4F, 3F), PartPose.offsetAndRotation(3.4F, 5F, 0F, -0.2F, 0F, -0.6F));
        PartDefinition fP4_1 = fP4_0.addOrReplaceChild("fP4_1", CubeListBuilder.create().texOffs(0, 138).addBox(-1F, 0F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.35F, 0F, 0F));
        PartDefinition fP4_2 = fP4_1.addOrReplaceChild("fP4_2", CubeListBuilder.create().texOffs(60, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.35F, 0F, 0F));
        PartDefinition shoulderN = torso.addOrReplaceChild("shoulderN", CubeListBuilder.create().texOffs(132, 30).addBox(-6F, -4F, -6F, 12F, 8F, 12F), PartPose.offsetAndRotation(-19F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition capN = shoulderN.addOrReplaceChild("capN", CubeListBuilder.create().texOffs(76, 53).addBox(-7F, -3F, -7F, 14F, 3F, 14F), PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition spsN0 = capN.addOrReplaceChild("spsN0", CubeListBuilder.create().texOffs(220, 100).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F), PartPose.offsetAndRotation(-3.5F, -3F, 0F, 0F, 0F, -0.5F));
        PartDefinition spsN1 = capN.addOrReplaceChild("spsN1", CubeListBuilder.create().texOffs(232, 100).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F), PartPose.offsetAndRotation(3.5F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition armN = shoulderN.addOrReplaceChild("armN", CubeListBuilder.create().texOffs(168, 0).addBox(-5F, 0F, -5F, 10F, 14F, 10F), PartPose.offsetAndRotation(0F, 3F, 0F, 0F, 0F, 0F));
        PartDefinition bicN = armN.addOrReplaceChild("bicN", CubeListBuilder.create().texOffs(154, 111).addBox(-4F, -3F, -3F, 8F, 6F, 3F), PartPose.offsetAndRotation(0F, 5F, -5F, 0F, 0F, 0F));
        PartDefinition foreN = armN.addOrReplaceChild("foreN", CubeListBuilder.create().texOffs(0, 30).addBox(-5F, 0F, -5F, 10F, 13F, 10F), PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, 0F));
        PartDefinition ringAN = foreN.addOrReplaceChild("ringAN", CubeListBuilder.create().texOffs(0, 86).addBox(-6F, 0F, -6F, 12F, 2F, 12F), PartPose.offsetAndRotation(0F, 3F, 0F, 0F, 0F, 0F));
        PartDefinition ringBN = foreN.addOrReplaceChild("ringBN", CubeListBuilder.create().texOffs(48, 71).addBox(-6F, 0F, -6F, 12F, 3F, 12F), PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition handN = foreN.addOrReplaceChild("handN", CubeListBuilder.create().texOffs(28, 100).addBox(-4F, 0F, -3F, 8F, 5F, 6F), PartPose.offsetAndRotation(0F, 13F, 0F, 0F, 0F, 0F));
        PartDefinition fN0_0 = handN.addOrReplaceChild("fN0_0", CubeListBuilder.create().texOffs(196, 130).addBox(-1.5F, 0F, -1.5F, 3F, 4F, 3F), PartPose.offsetAndRotation(-3.4F, 5F, 0F, -0.2F, 0F, 0.6F));
        PartDefinition fN0_1 = fN0_0.addOrReplaceChild("fN0_1", CubeListBuilder.create().texOffs(8, 138).addBox(-1F, 0F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN0_2 = fN0_1.addOrReplaceChild("fN0_2", CubeListBuilder.create().texOffs(66, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN1_0 = handN.addOrReplaceChild("fN1_0", CubeListBuilder.create().texOffs(36, 130).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(-1.7F, 5F, 0F, -0.2F, 0F, 0.3F));
        PartDefinition fN1_1 = fN1_0.addOrReplaceChild("fN1_1", CubeListBuilder.create().texOffs(208, 130).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN1_2 = fN1_1.addOrReplaceChild("fN1_2", CubeListBuilder.create().texOffs(72, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN2_0 = handN.addOrReplaceChild("fN2_0", CubeListBuilder.create().texOffs(48, 130).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.2F, 0F, 0F));
        PartDefinition fN2_1 = fN2_0.addOrReplaceChild("fN2_1", CubeListBuilder.create().texOffs(216, 130).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN2_2 = fN2_1.addOrReplaceChild("fN2_2", CubeListBuilder.create().texOffs(78, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN3_0 = handN.addOrReplaceChild("fN3_0", CubeListBuilder.create().texOffs(60, 130).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(1.7F, 5F, 0F, -0.2F, 0F, -0.3F));
        PartDefinition fN3_1 = fN3_0.addOrReplaceChild("fN3_1", CubeListBuilder.create().texOffs(224, 130).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN3_2 = fN3_1.addOrReplaceChild("fN3_2", CubeListBuilder.create().texOffs(84, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 5F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN4_0 = handN.addOrReplaceChild("fN4_0", CubeListBuilder.create().texOffs(232, 130).addBox(-1.5F, 0F, -1.5F, 3F, 4F, 3F), PartPose.offsetAndRotation(3.4F, 5F, 0F, -0.2F, 0F, -0.6F));
        PartDefinition fN4_1 = fN4_0.addOrReplaceChild("fN4_1", CubeListBuilder.create().texOffs(16, 138).addBox(-1F, 0F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.35F, 0F, 0F));
        PartDefinition fN4_2 = fN4_1.addOrReplaceChild("fN4_2", CubeListBuilder.create().texOffs(90, 144).addBox(-1F, 0F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.35F, 0F, 0F));
        PartDefinition sp0_0 = torso.addOrReplaceChild("sp0_0", CubeListBuilder.create().texOffs(176, 111).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(9F, -8F, 6F, -0.5F, 0F, 0.25F));
        PartDefinition sp0_1 = sp0_0.addOrReplaceChild("sp0_1", CubeListBuilder.create().texOffs(192, 111).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp0_2 = sp0_1.addOrReplaceChild("sp0_2", CubeListBuilder.create().texOffs(24, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp0_3 = sp0_2.addOrReplaceChild("sp0_3", CubeListBuilder.create().texOffs(32, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp1_0 = torso.addOrReplaceChild("sp1_0", CubeListBuilder.create().texOffs(208, 111).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(12F, -7F, 6F, -0.5F, 0F, 0.45F));
        PartDefinition sp1_1 = sp1_0.addOrReplaceChild("sp1_1", CubeListBuilder.create().texOffs(224, 111).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp1_2 = sp1_1.addOrReplaceChild("sp1_2", CubeListBuilder.create().texOffs(40, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp1_3 = sp1_2.addOrReplaceChild("sp1_3", CubeListBuilder.create().texOffs(48, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp2_0 = torso.addOrReplaceChild("sp2_0", CubeListBuilder.create().texOffs(240, 111).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(15F, -6F, 6F, -0.5F, 0F, 0.65F));
        PartDefinition sp2_1 = sp2_0.addOrReplaceChild("sp2_1", CubeListBuilder.create().texOffs(0, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp2_2 = sp2_1.addOrReplaceChild("sp2_2", CubeListBuilder.create().texOffs(56, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp2_3 = sp2_2.addOrReplaceChild("sp2_3", CubeListBuilder.create().texOffs(64, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp3_0 = torso.addOrReplaceChild("sp3_0", CubeListBuilder.create().texOffs(16, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(18F, -5F, 6F, -0.5F, 0F, 0.85F));
        PartDefinition sp3_1 = sp3_0.addOrReplaceChild("sp3_1", CubeListBuilder.create().texOffs(32, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp3_2 = sp3_1.addOrReplaceChild("sp3_2", CubeListBuilder.create().texOffs(72, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp3_3 = sp3_2.addOrReplaceChild("sp3_3", CubeListBuilder.create().texOffs(80, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp4_0 = torso.addOrReplaceChild("sp4_0", CubeListBuilder.create().texOffs(48, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(20F, -3F, 6F, -0.5F, 0F, 1.05F));
        PartDefinition sp4_1 = sp4_0.addOrReplaceChild("sp4_1", CubeListBuilder.create().texOffs(64, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp4_2 = sp4_1.addOrReplaceChild("sp4_2", CubeListBuilder.create().texOffs(88, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp4_3 = sp4_2.addOrReplaceChild("sp4_3", CubeListBuilder.create().texOffs(96, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp5_0 = torso.addOrReplaceChild("sp5_0", CubeListBuilder.create().texOffs(80, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-9F, -8F, 6F, -0.5F, 0F, -0.25F));
        PartDefinition sp5_1 = sp5_0.addOrReplaceChild("sp5_1", CubeListBuilder.create().texOffs(96, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp5_2 = sp5_1.addOrReplaceChild("sp5_2", CubeListBuilder.create().texOffs(104, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp5_3 = sp5_2.addOrReplaceChild("sp5_3", CubeListBuilder.create().texOffs(112, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp6_0 = torso.addOrReplaceChild("sp6_0", CubeListBuilder.create().texOffs(112, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-12F, -7F, 6F, -0.5F, 0F, -0.45F));
        PartDefinition sp6_1 = sp6_0.addOrReplaceChild("sp6_1", CubeListBuilder.create().texOffs(128, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp6_2 = sp6_1.addOrReplaceChild("sp6_2", CubeListBuilder.create().texOffs(120, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp6_3 = sp6_2.addOrReplaceChild("sp6_3", CubeListBuilder.create().texOffs(128, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp7_0 = torso.addOrReplaceChild("sp7_0", CubeListBuilder.create().texOffs(144, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-15F, -6F, 6F, -0.5F, 0F, -0.65F));
        PartDefinition sp7_1 = sp7_0.addOrReplaceChild("sp7_1", CubeListBuilder.create().texOffs(160, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp7_2 = sp7_1.addOrReplaceChild("sp7_2", CubeListBuilder.create().texOffs(136, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp7_3 = sp7_2.addOrReplaceChild("sp7_3", CubeListBuilder.create().texOffs(144, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp8_0 = torso.addOrReplaceChild("sp8_0", CubeListBuilder.create().texOffs(176, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-18F, -5F, 6F, -0.5F, 0F, -0.85F));
        PartDefinition sp8_1 = sp8_0.addOrReplaceChild("sp8_1", CubeListBuilder.create().texOffs(192, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp8_2 = sp8_1.addOrReplaceChild("sp8_2", CubeListBuilder.create().texOffs(152, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp8_3 = sp8_2.addOrReplaceChild("sp8_3", CubeListBuilder.create().texOffs(160, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp9_0 = torso.addOrReplaceChild("sp9_0", CubeListBuilder.create().texOffs(208, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-20F, -3F, 6F, -0.5F, 0F, -1.05F));
        PartDefinition sp9_1 = sp9_0.addOrReplaceChild("sp9_1", CubeListBuilder.create().texOffs(224, 121).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp9_2 = sp9_1.addOrReplaceChild("sp9_2", CubeListBuilder.create().texOffs(168, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp9_3 = sp9_2.addOrReplaceChild("sp9_3", CubeListBuilder.create().texOffs(176, 138).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition pack = torso.addOrReplaceChild("pack", CubeListBuilder.create().texOffs(40, 30).addBox(-7F, -7F, 0F, 14F, 14F, 8F), PartPose.offsetAndRotation(0F, 0F, 6F, 0F, 0F, 0F));
        PartDefinition podP = pack.addOrReplaceChild("podP", CubeListBuilder.create().texOffs(220, 30).addBox(-2F, -6F, -3F, 4F, 12F, 6F), PartPose.offsetAndRotation(9F, 0F, 4F, 0F, 0F, 0F));
        PartDefinition podN = pack.addOrReplaceChild("podN", CubeListBuilder.create().texOffs(0, 53).addBox(-2F, -6F, -3F, 4F, 12F, 6F), PartPose.offsetAndRotation(-9F, 0F, 4F, 0F, 0F, 0F));
        PartDefinition engine0 = pack.addOrReplaceChild("engine0", CubeListBuilder.create().texOffs(56, 100).addBox(-4F, 0F, -4F, 8F, 3F, 8F), PartPose.offsetAndRotation(-5F, 7F, 4F, 0F, 0F, 0F));
        PartDefinition eorb0 = engine0.addOrReplaceChild("eorb0", CubeListBuilder.create().texOffs(124, 86).addBox(-3F, -3F, -3F, 6F, 6F, 6F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition engine1 = pack.addOrReplaceChild("engine1", CubeListBuilder.create().texOffs(88, 100).addBox(-4F, 0F, -4F, 8F, 3F, 8F), PartPose.offsetAndRotation(0F, 7F, 4F, 0F, 0F, 0F));
        PartDefinition eorb1 = engine1.addOrReplaceChild("eorb1", CubeListBuilder.create().texOffs(148, 86).addBox(-3F, -3F, -3F, 6F, 6F, 6F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition engine2 = pack.addOrReplaceChild("engine2", CubeListBuilder.create().texOffs(120, 100).addBox(-4F, 0F, -4F, 8F, 3F, 8F), PartPose.offsetAndRotation(5F, 7F, 4F, 0F, 0F, 0F));
        PartDefinition eorb2 = engine2.addOrReplaceChild("eorb2", CubeListBuilder.create().texOffs(172, 86).addBox(-3F, -3F, -3F, 6F, 6F, 6F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition pelvis = torso.addOrReplaceChild("pelvis", CubeListBuilder.create().texOffs(148, 53).addBox(-8F, -3F, -5F, 16F, 6F, 10F), PartPose.offsetAndRotation(0F, 11F, 0F, 0F, 0F, 0F));
        PartDefinition orb = pelvis.addOrReplaceChild("orb", CubeListBuilder.create().texOffs(180, 30).addBox(-5F, -5F, -5F, 10F, 10F, 10F), PartPose.offsetAndRotation(0F, 1F, -7F, 0F, 0F, 0F));
        PartDefinition tail0 = pelvis.addOrReplaceChild("tail0", CubeListBuilder.create().texOffs(48, 86).addBox(-6F, 0F, -4F, 12F, 6F, 8F), PartPose.offsetAndRotation(0F, 3F, 0F, 0F, 0F, 0F));
        PartDefinition tail1 = tail0.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(88, 86).addBox(-5F, 0F, -4F, 10F, 6F, 8F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail2 = tail1.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(196, 86).addBox(-4F, 0F, -3F, 8F, 6F, 6F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail3 = tail2.addOrReplaceChild("tail3", CubeListBuilder.create().texOffs(224, 86).addBox(-4F, 0F, -3F, 8F, 6F, 6F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail4 = tail3.addOrReplaceChild("tail4", CubeListBuilder.create().texOffs(0, 111).addBox(-3F, 0F, -2F, 6F, 6F, 4F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail5 = tail4.addOrReplaceChild("tail5", CubeListBuilder.create().texOffs(20, 111).addBox(-2F, 0F, -2F, 4F, 6F, 4F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail6 = tail5.addOrReplaceChild("tail6", CubeListBuilder.create().texOffs(72, 130).addBox(-2F, 0F, -1F, 4F, 6F, 2F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail7 = tail6.addOrReplaceChild("tail7", CubeListBuilder.create().texOffs(240, 121).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 320);
    }

    /** Quanto o olho desliza para os lados (em pixels do modelo). Cada boss tem seu próprio ritmo. */
    private static final float EYE_RANGE = 1.5F;   // máximo que o olho se afasta do centro
    private static final float EYE_CYCLE = 80.0F;  // ticks por ciclo (4 s); em alguns ciclos ele fica parado

    private static float smooth(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    private static float eyeOffset(float time, int id) {
        float tt = time + (id * 37) % 100;
        int cyc = (int) Math.floor(tt / EYE_CYCLE);
        float p = (tt - cyc * EYE_CYCLE) / EYE_CYCLE;
        int h = cyc * 0x9E3779B1 + id * 0x85EBCA6B;
        h ^= h >>> 15; h *= 0x2C1B3C6D; h ^= h >>> 12; h &= 0x7fffffff;
        int kind = h % 5;                              // 0-1: parado, 2-3: uma olhada, 4: olha pros dois lados
        float dir = ((h >> 8) & 1) == 0 ? -1.0F : 1.0F;
        if (kind < 2) return 0.0F;
        if (kind < 4) {
            return dir * EYE_RANGE * (smooth((p - 0.10F) / 0.08F) - smooth((p - 0.55F) / 0.10F));
        }
        return dir * EYE_RANGE * (smooth((p - 0.10F) / 0.08F) - 2.0F * smooth((p - 0.38F) / 0.10F) + smooth((p - 0.66F) / 0.10F));
    }

    @Override
    public void setupAnim(CosmicBoss e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        float t = age;
        float[] w = e.getPoseWeights(); // 0 parado, 1 orbes, 2 pulso, 3 raio
        int atkTick = e.getAtkTick();
        computeThrow(e, atkTick > 0 ? atkTick + (age - e.tickCount) : 0.0F);

        torso.y = TORSO_Y + Mth.sin(t * 0.09F) * 1.6F;
        torso.xRot = 0.05F + w[2] * -0.2F + w[3] * 0.1F
                // arremesso: inclina para trás ao preparar e para frente ao soltar
                - 0.12F * (throwWind[0] + throwWind[1]) + 0.18F * (throwRel[0] + throwRel[1]);
        head.yRot = yaw * RAD * 0.7F;
        head.xRot = pitch * RAD * 0.7F;
        // o olho desliza de vez em quando para os lados
        eye.x = eyeOffset(t, e.getId());

        // parado: braço desce para o lado e o antebraço dobra PARA FRENTE, mãos abertas
        float armX = w[0] * -0.35F + w[1] * -1.2F + w[3] * -1.5F;
        float armZ = w[0] * (0.75F + Mth.sin(t * 0.08F) * 0.06F) + w[1] * 0.3F + w[2] * 2.7F + w[3] * 0.12F;
        float foreX = w[0] * -1.45F + w[1] * -0.5F + w[3] * -0.1F;
        float foreIn = w[0] * 0.15F;
        float open = 1.0F + 0.5F * (w[1] + w[3]) + 0.6F * w[2];
        for (int s = 0; s < 2; s++) {
            float sg = s == 0 ? -1.0F : 1.0F; // lado +x gira para fora com z negativo
            float tw = throwWind[s], tr = throwRel[s];
            // preparação: braço sobe e vai para trás; soltura: chicoteia para frente, passando um pouco do ponto
            float armAdd = -1.3F * (tw + tr) + (tr > 0.0F ? 0.7F * Mth.sin((1.0F - tr) * (float) Math.PI) : 0.0F);
            arm[s].xRot = armX + armAdd;
            arm[s].zRot = sg * armZ;
            fore[s].xRot = foreX - 0.8F * (tw + tr);
            fore[s].yRot = -sg * foreIn;
            hand[s].xRot = w[0] * -0.2F + w[1] * -0.1F;
            for (int k = 0; k < 5; k++) {
                for (int m = 0; m < FING_SEGS; m++) {
                    fing[s][k][m].xRot = fingBaseX[s][k][m] + Mth.sin(t * 0.12F + k + m * 0.5F) * 0.05F;
                    fing[s][k][m].zRot = fingBaseZ[s][k][m] * (open + 0.7F * tw + 0.5F * tr);
                }
            }
        }

        for (int i = 0; i < TAIL_SEGS; i++) {
            tail[i].xRot = 0.06F + Mth.sin(t * 0.09F - i * 0.6F) * 0.10F;
            tail[i].yRot = Mth.sin(t * 0.07F - i * 0.7F) * 0.20F;
        }
        orb.yRot = t * 0.04F;
        orb.xRot = t * 0.025F;
        for (int i = 0; i < 3; i++) {
            engineOrb[i].yRot = t * 0.05F + i;
            engineOrb[i].xRot = t * 0.03F;
        }
        for (int i = 0; i < SPIKES; i++) {
            for (int k = 0; k < SPIKE_SEGS; k++) {
                float ph = t * 0.06F + i * 0.7F + k * 0.6F;
                spike[i][k].zRot = spikeBaseZ[i][k] + Mth.sin(ph) * 0.05F;
                spike[i][k].xRot = spikeBaseX[i][k] + Mth.cos(ph) * 0.03F;
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buf, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buf, light, overlay, r, g, b, a);
    }
}
